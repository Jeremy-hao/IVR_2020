# IVR Assignment 
## Theodor Amariucai s1703913 and Sonia Marshall s1704145

To run the assignment please run the following nodes:

BlobsEstimator.py \
TargetEstimator.py \
JointAnglesEstimator.py 

then, to get the results of forward kinematics please run:

ForwardKinematics.py 

and finally, to move the robot please run:

Controller.py

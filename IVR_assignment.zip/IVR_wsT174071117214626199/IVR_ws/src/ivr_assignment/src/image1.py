#!/usr/bin/env python3

import roslib
import sys
import rospy
import cv2
import math
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image
from std_msgs.msg import Float64MultiArray, Float64
from cv_bridge import CvBridge, CvBridgeError


class image_converter:

# Defines publisher and subscriber
    def __init__(self):
        # initialize the node named image_processing
        rospy.init_node('image_processing', anonymous=True)
        rate = rospy.Rate(30) # 30hz
        robot_joint2_pub = rospy.Publisher("/robot/joint2_position_controller/command", Float64, queue_size=10)
        robot_joint3_pub = rospy.Publisher("/robot/joint3_position_controller/command", Float64, queue_size=10)
        robot_joint4_pub = rospy.Publisher("/robot/joint4_position_controller/command", Float64, queue_size=10)
        self.estimate_joint2_pub = rospy.Publisher("/robot/estimate_joint2", Float64, queue_size=10)
        self.estimate_joint3_pub = rospy.Publisher("/robot/estimate_joint3", Float64, queue_size=10)
        self.estimate_joint4_pub = rospy.Publisher("/robot/estimate_joint4", Float64, queue_size=10)
        # initialize a subscriber to recieve messages rom a topic named /robot/camera1/image_raw and use callback function to recieve data
        self.bridge = CvBridge()
        self.blob_pub = rospy.Publisher("/blobs_pos", Float64MultiArray, queue_size=10)
        self.blobs = Float64MultiArray()
        self.blobs_history = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.5, 2.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        self.image_sub2 = rospy.Subscriber("/camera2/robot/image_raw",Image,self.callback2)
        rospy.sleep(0.4)
        self.image_sub1 = rospy.Subscriber("/camera1/robot/image_raw",Image,self.callback1)
        rospy.sleep(0.4)
        # initialize the bridge between openCV and ROS
        

        t0 = rospy.get_time()
        while not rospy.is_shutdown():
            cur_time = np.array([rospy.get_time()])-t0
            joint1=0
            joint2 = np.pi/2* np.sin(cur_time * np.pi/15)
            joint3 = np.pi/2* np.sin(cur_time * np.pi/18)
            joint4 = np.pi/2* np.sin(cur_time * np.pi/20)
            self.CalculateAngles()
            #print(joint4)
            robot_joint2_pub.publish(joint2)
            robot_joint3_pub.publish(joint3)
            robot_joint4_pub.publish(joint4)
            rate.sleep()
    def CalculateAngles(self):
        ja1=0
        ja2=np.pi/2-np.arctan2((self.blobs.data[6] - self.blobs.data[10]), (self.blobs.data[5] - self.blobs.data[9]))
        ja3 = np.arctan2((self.blobs.data[7] - self.blobs.data[11]), (self.blobs.data[4] - self.blobs.data[8]))-np.pi/2
        ja4 = np.arctan2((self.blobs.data[10] - self.blobs.data[14]), -(self.blobs.data[9] - self.blobs.data[13]))-np.pi/2-ja2
        #print(ja4)
        if ja2 > 3.14:
            ja2 = ja2 - np.pi
        elif ja2 > 1.57:
            ja2 = np.pi - ja2
        if ja3 < -3.14:
            ja3 = abs(ja3)-3.14
        if ja4 < -6.28:
            ja4 = abs(ja4)-6.28
        elif ja4 < -4.71:
            ja4 = 6.28-abs(ja4)
        elif ja4 < -3.14:
            ja4 = abs(ja4)-3.14
        elif ja4 < 0:
            ja4 = ja4 + 1.57
        self.estimate_joint2_pub.publish(ja2)
        self.estimate_joint3_pub.publish(ja3)
        self.estimate_joint4_pub.publish(ja4)
        print("THETA 1:{0:.2f}, THETA 2:{1:.2f}, THETA 3:{2:.2f}, THETA 4:{3:.2f}".format(ja1,
                                                                                          ja2,
                                                                                          ja3,
                                                                                          ja4), end='\r')
    # Detecting the centre of the green circle
    def detect_green(self,image):
        mask = cv2.inRange(image, (0, 100, 0), (80, 255, 80))
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.dilate(mask, kernel, iterations=3)
        M = cv2.moments(mask)
        cx = int(M['m10'] / (M['m00']+1e-10))
        cy = int(M['m01'] / (M['m00']+1e-10))
        return np.array([cx, cy])

    def detect_red(self,image):
        # Isolate the blue colour in the image as a binary image
        mask = cv2.inRange(image, (0, 0, 100), (10, 10, 255))
        # This applies a dilate that makes the binary region larger (the more iterations the larger it becomes)
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.dilate(mask, kernel, iterations=3)
        # Obtain the moments of the binary image
        M = cv2.moments(mask)
        # Calculate pixel coordinates for the centre of the blob
        cx = int(M['m10'] / (M['m00']+1e-10))
        cy = int(M['m01'] / (M['m00']+1e-10))
        return np.array([cx, cy])

    # Detecting the centre of the blue circle
    def detect_blue(self,image):
        mask = cv2.inRange(image, (100, 0, 0), (255, 80, 80))
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.dilate(mask, kernel, iterations=3)
        M = cv2.moments(mask)
        cx = int(M['m10'] / (M['m00']+1e-10))
        cy = int(M['m01'] / (M['m00']+1e-10))
        return np.array([cx, cy])

    # Detecting the centre of the yellow circle
    def detect_yellow(self,image):
        mask = cv2.inRange(image, (0, 100, 100), (0, 200, 200))
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.dilate(mask, kernel, iterations=3)
        M = cv2.moments(mask)
        cx = int(M['m10'] / (M['m00']+1e-10))
        cy = int(M['m01'] / (M['m00']+1e-10))
        return np.array([cx, cy])


    # Calculate the conversion from pixel to meter
    def pixel2meter(self,image):
        # Obtain the centre of each coloured blob
        circle1Pos = self.detect_blue(image)
        circle2Pos = self.detect_yellow(image)
        # find the distance between two circles
        dist = np.sum((circle1Pos - circle2Pos)**2)
        return 2.5 / np.sqrt(dist)

    # Recieve data from camera 1, process it, and publish
    def callback1(self,data):
        # Recieve the image
        try:
            self.cv_image1 = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            print(e)
        if len(self.blobs.data) == 0:
            new_blobs = self.blobs_history
        else:
            new_blobs = self.blobs.data
            self.blobs_history = new_blobs

        img1_meters_ratio=self.pixel2meter(self.cv_image1)

        base_frame=self.detect_yellow(self.cv_image1)

        blue_detected = self.detect_blue(self.cv_image1)
        relative_blue = base_frame - blue_detected
        new_blobs[5] = img1_meters_ratio * relative_blue[0]
        new_blobs[6] = img1_meters_ratio * relative_blue[1]

        green_detected=self.detect_green(self.cv_image1)
        relative_green = base_frame - green_detected
        new_blobs[9] = img1_meters_ratio * relative_green[0]
        new_blobs[10] = img1_meters_ratio * relative_green[1]

        red_detected = self.detect_red(self.cv_image1)
        relative_red = base_frame - red_detected
        new_blobs[13] = img1_meters_ratio * relative_red[0]
        new_blobs[14] = img1_meters_ratio * relative_red[1]
        
        self.blobs.data = new_blobs
        self.blob_pub.publish(self.blobs)
        
        #print(self.blobs.data)

    def callback2(self,data):
        # Recieve the image
        try:
          self.cv_image2 = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
          print(e)

        if len(self.blobs.data) == 0:
            new_blobs = self.blobs_history
        else:
            new_blobs = self.blobs.data
            self.blobs_history = new_blobs

        img2_meters_ratio=self.pixel2meter(self.cv_image2)

        base_frame=self.detect_yellow(self.cv_image2)

        blue_detected = self.detect_blue(self.cv_image2)
        relative_blue = base_frame - blue_detected
        new_blobs[4] = img2_meters_ratio * relative_blue[0]
        new_blobs[7] = img2_meters_ratio * relative_blue[1]

        green_detected=self.detect_green(self.cv_image2)
        relative_green = base_frame - green_detected
        new_blobs[8] = img2_meters_ratio * relative_green[0]
        new_blobs[11] = img2_meters_ratio * relative_green[1]

        red_detected = self.detect_red(self.cv_image2)
        relative_red = base_frame - red_detected
        new_blobs[12] = img2_meters_ratio * relative_red[0]
        new_blobs[15] = img2_meters_ratio * relative_red[1]
        
        self.blobs.data = new_blobs
        self.blob_pub.publish(self.blobs)
        
        #print(self.blobs.data)
        

# call the class
def main(args):
    ic = image_converter()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")
        cv2.destroyAllWindows()

# run the code if the node is called
if __name__ == '__main__':
    main(sys.argv)


